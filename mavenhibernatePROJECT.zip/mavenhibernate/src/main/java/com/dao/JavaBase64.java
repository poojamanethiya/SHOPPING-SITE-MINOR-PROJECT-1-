package com.dao;

import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class JavaBase64 {

	public String Encrypt(String password) {

	Encoder encoder=Base64.getEncoder();
	
	String encodedpassword=encoder.encodeToString(password.getBytes()); 
	System.out.println(encodedpassword);
	return encodedpassword;
	}
	public String Decrypt(String password) {
		Decoder decoder=Base64.getDecoder();
		byte[]bytes=decoder.decode(password);
		String result=new String(bytes);
		return result;
	}
	
}

